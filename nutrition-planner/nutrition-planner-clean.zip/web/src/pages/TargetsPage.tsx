// src/pages/TargetsPage.tsx
import { useEffect, useState } from 'react'
import type { Targets } from '../types'
import { getTargets } from '../api'

export default function TargetsPage() {
  const [targets, setTargets] = useState<Targets | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    getTargets()
      .then(setTargets)
      .catch((e) => setError(String(e)))
  }, [])

  if (error) return <div style={{ color: 'crimson' }}>Erreur: {error}</div>
  if (!targets) return <div>Chargement…</div>

  return (
    <div>
      <h2>Profils nutritionnels</h2>
      <ul>
        <li>Calories / jour: {targets.kcal_per_day}</li>
        <li>Protéines / jour: {targets.protein_g_per_day} g</li>
        <li>Glucides / jour: {targets.carbs_g_per_day} g</li>
        <li>Lipides / jour: {targets.fat_g_per_day} g</li>
      </ul>
    </div>
  )
}
