import { useEffect, useState } from 'react';
import { listIngredients } from '../api';
import type { Ingredient } from '../types';
import { Link } from 'react-router-dom';

export default function IngredientsPage() {
  const [items, setItems] = useState<Ingredient[]>([]);
  const [q, setQ] = useState('');

  useEffect(() => { listIngredients().then(setItems).catch(console.error); }, []);
  const filtered = items.filter(i => i.name.toLowerCase().includes(q.toLowerCase()));

  return (
    <div style={{ padding: 16 }}>
      <h3>Ingrédients</h3>
      <input
        placeholder="Rechercher…"
        value={q}
        onChange={e => setQ(e.target.value)}
        style={{ padding: 8, border: '1px solid #e5e7eb', borderRadius: 8, margin: '8px 0', width: 280 }}
      />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 10 }}>
        {filtered.map((ing) => (
          <div key={ing.id} style={{ border: '1px solid #e5e7eb', borderRadius: 8, padding: 12, background: '#fff' }}>
            <div style={{ fontWeight: 600 }}>{ing.name}</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>{ing.category ?? '—'}</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <Link to={`/ingredients/${ing.id}`}>
                <button>Ouvrir</button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
