import { useEffect, useState } from 'react'
import { listCiqualIngredients } from '../api'
import type { IngredientCiqual } from '../types'

export default function CiqualIngredientList() {
  const [q, setQ] = useState('')
  const [items, setItems] = useState<IngredientCiqual[]>([])

  useEffect(() => {
    const t = setTimeout(() => {
      listCiqualIngredients(q).then(setItems).catch(()=>setItems([]))
    }, 250)
    return () => clearTimeout(t)
  }, [q])

  return (
    <div className="max-w-5xl mx-auto p-6">
      <h1 className="text-2xl font-semibold mb-3">Ingrédients CIQUAL</h1>
      <input className="border rounded px-3 py-2 mb-3 w-80" placeholder="Rechercher…" value={q} onChange={e=>setQ(e.target.value)} />
      <div className="border rounded">
        <table className="w-full text-sm">
          <thead className="bg-gray-50">
            <tr>
              <th className="text-left px-3 py-2">Code</th>
              <th className="text-left px-3 py-2">Nom</th>
              <th className="text-left px-3 py-2">Groupe</th>
              <th className="text-right px-3 py-2">kcal</th>
              <th className="text-right px-3 py-2">Prot</th>
              <th className="text-right px-3 py-2">Glu</th>
              <th className="text-right px-3 py-2">Lip</th>
            </tr>
          </thead>
          <tbody>
            {items.map(r => (
              <tr key={r.ciqual_code} className="border-t">
                <td className="px-3 py-2 font-mono text-xs">{r.ciqual_code}</td>
                <td className="px-3 py-2">{r.name_fr}</td>
                <td className="px-3 py-2 text-gray-600">{r.grp_name_fr ?? r.subgrp_name_fr ?? ''}</td>
                <td className="px-3 py-2 text-right">{fmt(r.energy_kcal)}</td>
                <td className="px-3 py-2 text-right">{fmt(r.protein_g)}</td>
                <td className="px-3 py-2 text-right">{fmt(r.carbs_g)}</td>
                <td className="px-3 py-2 text-right">{fmt(r.fat_g)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
function fmt(x?: number | null) { return x == null ? '—' : x.toFixed(1) }
