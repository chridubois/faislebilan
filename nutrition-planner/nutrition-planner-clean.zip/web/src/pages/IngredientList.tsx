import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import type { Ingredient } from '../types';

export default function IngredientList() {
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/ingredients')
      .then(r => {
        if (!r.ok) throw new Error(`API ${r.status}`);
        return r.json();
      })
      .then(setIngredients)
      .catch(e => setError(String(e)));
  }, []);

  if (error) return <div style={{ color: 'crimson' }}>Erreur: {error}</div>;
  if (!ingredients.length) return <div>Chargement…</div>;

  return (
    <div>
      <h2>Liste des ingrédients</h2>
      <ul>
        {ingredients.map(ing => (
          <li key={ing.id} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span>{ing.name}</span>
            <Link
              to={`/ingredients/${ing.id}`}
              style={{
                padding: '6px 12px',
                border: '1px solid #ddd',
                borderRadius: 6,
                background: '#f3f4f6',
                textDecoration: 'none',
                fontSize: 14,
              }}
            >
              Voir détail
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
