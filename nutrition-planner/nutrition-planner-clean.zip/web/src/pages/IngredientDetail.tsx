// src/pages/IngredientDetail.tsx
import { useEffect, useMemo, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getIngredient } from '../api'
import type { Ingredient, IngredientState } from '../types'

type Row = { key: string; label: string; value: number; unit?: string; per?: string | undefined }

const NICE_LABEL: Record<string, string> = {
  energy_kcal: 'Énergie',
  protein: 'Protéines',
  carbs: 'Glucides',
  sugars: 'Sucres',
  fiber: 'Fibres',
  fat_total: 'Lipides',
  sodium: 'Sodium',
  calcium: 'Calcium',
  iron: 'Fer',
  magnesium: 'Magnésium',
  zinc: 'Zinc',
  potassium: 'Potassium',
  iodine: 'Iode',
  selenium: 'Sélénium',
  vitamin_A_RAE: 'Vitamine A (RAE)',
  vitamin_D: 'Vitamine D',
  vitamin_E: 'Vitamine E',
  vitamin_C: 'Vitamine C',
  thiamin_B1: 'Vitamine B1',
  riboflavin_B2: 'Vitamine B2',
  niacin_B3: 'Vitamine B3',
  vitamin_B6: 'Vitamine B6',
  folate_B9: 'Vitamine B9',
  cobalamin_B12: 'Vitamine B12',
  omega3_ALA: 'Oméga-3 ALA',
  omega3_EPA: 'Oméga-3 EPA',
  omega3_DHA: 'Oméga-3 DHA',
}

const PRIMARY_ORDER = [
  'energy_kcal',
  'protein',
  'carbs',
  'sugars',
  'fiber',
  'fat_total',
  'sodium',
]

function toRows(st: IngredientState | undefined): Row[] {
  if (!st) return []
  const rows: Row[] = []
  const nut = st.nutrients || {}

  for (const k of Object.keys(nut)) {
    const node = nut[k] as number | { value: number; unit?: string; per?: string }

    if (typeof node === 'number') {
      rows.push({ key: k, label: NICE_LABEL[k] || k, value: node })
    } else if (node && typeof node === 'object') {
      rows.push({
        key: k,
        label: NICE_LABEL[k] || k,
        value: Number(node.value ?? 0),
        unit: node.unit,
        per: node.per,
      })
    }
  }

  // tri: macros d'abord puis alpha
  rows.sort((a, b) => {
    const ia = PRIMARY_ORDER.indexOf(a.key)
    const ib = PRIMARY_ORDER.indexOf(b.key)
    if (ia >= 0 && ib >= 0) return ia - ib
    if (ia >= 0) return -1
    if (ib >= 0) return 1
    return a.label.localeCompare(b.label, 'fr')
  })

  return rows
}


export default function IngredientDetail() {
  const { id } = useParams<{ id: string }>()
  const [ing, setIng] = useState<Ingredient | null>(null)
  const [err, setErr] = useState<string | null>(null)
  const [activeState, setActiveState] = useState<string | null>(null)

  useEffect(() => {
    if (!id) return
    getIngredient(id)
      .then((res) => {
        setIng(res)
        const keys = Object.keys(res.states || {})
        setActiveState((cur) => cur ?? keys[0] ?? null)
      })
      .catch((e) => setErr(String(e)))
  }, [id])

  const stateObj: IngredientState | undefined = useMemo(() => {
    if (!ing || !activeState) return undefined
    return (ing.states || {})[activeState]
  }, [ing, activeState])

  const rows = useMemo(() => toRows(stateObj), [stateObj])
  const stateKeys = Object.keys(ing?.states || {})

  if (err) return <div style={{ padding: 16, color: 'crimson' }}>Erreur : {err}</div>
  if (!ing) return <div style={{ padding: 16 }}>Chargement…</div>

  return (
    <div style={{ padding: 16 }}>
      <div style={{ marginBottom: 8 }}>
        <Link to="/ingredients" style={{ textDecoration: 'none', color: '#646cff' }}>
          ← Retour à la liste
        </Link>
      </div>

      <h2 style={{ margin: '8px 0 12px' }}>{ing.name}</h2>

      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 12 }}>
        <div><b>Catégorie:</b> {ing.category ?? '—'}</div>
        <div><b>Labels:</b> {(ing.labels || []).join(', ') || '—'}</div>
        <div><b>Allergènes:</b> {(ing.allergens || []).join(', ') || '—'}</div>
      </div>

      <h3 style={{ marginTop: 8 }}>États disponibles</h3>
      {stateKeys.length === 0 ? (
        <div>—</div>
      ) : (
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', margin: '8px 0 12px' }}>
          {stateKeys.map((st) => {
            const active = st === activeState
            return (
              <button
                key={st}
                onClick={() => setActiveState(st)}
                style={{
                  padding: '8px 12px',
                  border: '1px solid ' + (active ? '#2563eb' : '#e5e7eb'),
                  background: active ? '#eef2ff' : '#fff',
                  color: active ? '#1d4ed8' : '#111',
                  borderRadius: 8,
                }}
              >
                {st}
              </button>
            )
          })}
        </div>
      )}

      {/* Métadonnées de l’état sélectionné */}
      {stateObj && (
        <div
          style={{
            border: '1px solid #e5e7eb',
            borderRadius: 10,
            padding: 12,
            background: '#fff',
            marginBottom: 12,
          }}
        >
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            {'portion_ref' in stateObj && stateObj.portion_ref ? (
              <div>
                <b>Portion de réf. :</b>{' '}
                {stateObj.portion_ref?.amount} {stateObj.portion_ref?.unit}
              </div>
            ) : null}
            {'portion_weight_g' in stateObj && stateObj.portion_weight_g ? (
              <div>
                <b>Poids d’une portion :</b> {stateObj.portion_weight_g} g
              </div>
            ) : null}
          </div>
        </div>
      )}

      <h3 style={{ marginTop: 8 }}>Nutriments ({activeState ?? '—'})</h3>
      {rows.length === 0 ? (
        <div>—</div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table
            style={{
              width: '100%',
              borderCollapse: 'collapse',
              background: '#fff',
              border: '1px solid #e5e7eb',
              borderRadius: 10,
              overflow: 'hidden',
            }}
          >
            <thead style={{ background: '#f8fafc' }}>
              <tr>
                <th style={th}>Nutriment</th>
                <th style={th}>Valeur</th>
                <th style={th}>Unité</th>
                <th style={th}>Base</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.key}>
                  <td style={td}>{r.label}</td>
                  <td style={td}>
                    {Math.abs(r.value) >= 100 ? Math.round(r.value) : Math.round(r.value * 10) / 10}
                  </td>
                  <td style={td}>{r.unit ?? '—'}</td>
                  <td style={td}>{r.per ?? '100g'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

const th: React.CSSProperties = {
  textAlign: 'left',
  padding: '10px 12px',
  borderBottom: '1px solid #e5e7eb',
  fontWeight: 600,
  fontSize: 13,
  color: '#111827',
}

const td: React.CSSProperties = {
  padding: '8px 12px',
  borderBottom: '1px solid #f1f5f9',
  fontSize: 14,
}
