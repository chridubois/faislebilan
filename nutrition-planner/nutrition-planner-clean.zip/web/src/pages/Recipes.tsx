import React, { useEffect, useMemo, useState } from 'react'
import { listRecipes } from '../api'
import type { Recipe, MealSlot } from '../types'
import { Link } from 'react-router-dom'

type SlotFilter = MealSlot | 'all'
const MEAL_SLOTS: readonly MealSlot[] = ['breakfast', 'lunch', 'dinner'] as const
const isMealSlot = (s: string): s is MealSlot => MEAL_SLOTS.includes(s as MealSlot)

export default function RecipesPage() {
  const [items, setItems] = useState<Recipe[]>([])
  const [q, setQ] = useState('')
  const [slot, setSlot] = useState<SlotFilter>('all')

  useEffect(() => {
    listRecipes().then(setItems).catch(console.error)
  }, [])

  const filtered = useMemo(() => {
    const ql = q.toLowerCase()
    return items.filter((r) => {
      const okQuery = r.name.toLowerCase().includes(ql)
      const okSlot =
        slot === 'all' ? true : ((r.meal_types || []) as MealSlot[]).includes(slot)
      return okQuery && okSlot
    })
  }, [items, q, slot])

  return (
    <div style={{ padding: 16 }}>
      <h3>Recettes</h3>

      <div style={{ display: 'flex', gap: 8, margin: '8px 0' }}>
        <input
          placeholder="Rechercher…"
          value={q}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setQ(e.target.value)}
          style={{ padding: 8, border: '1px solid #e5e7eb', borderRadius: 8, width: 280 }}
        />
        <select
          value={slot}
          onChange={(e: React.ChangeEvent<HTMLSelectElement>) => {
            const v = e.target.value
            setSlot(isMealSlot(v) ? v : 'all')
          }}
          style={{ padding: 8, border: '1px solid #e5e7eb', borderRadius: 8 }}
        >
          <option value="all">Tous les slots</option>
          <option value="breakfast">Petit-déj</option>
          <option value="lunch">Déjeuner</option>
          <option value="dinner">Dîner</option>
        </select>
      </div>

      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
          gap: 10,
        }}
      >
        {filtered.map((r) => (
          <div
            key={r.id}
            style={{
              border: '1px solid #e5e7eb',
              borderRadius: 8,
              padding: 12,
              background: '#fff',
            }}
          >
            <div style={{ fontWeight: 600 }}>{r.name}</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>
              {(r.meal_types || []).join(', ') || '—'} • {r.time_min ?? 15} min • {r.portions}{' '}
              portions
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8 }}>
              <Link to={`/recipes/${r.id}`}>
                <button>Ouvrir</button>
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
