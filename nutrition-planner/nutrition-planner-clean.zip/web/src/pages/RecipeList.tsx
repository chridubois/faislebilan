// src/pages/RecipeList.tsx
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import type { MealSlot } from '../types'

// Définition du type attendu depuis l'API
type AuditRow = {
  id: string
  name: string
  kcal_per_portion: number
  protein_g: number
  carbs_g: number
  fat_g: number
  meal_types: MealSlot[]
  portions: number
  dish_family?: string | null
  time_min?: number | null
}

export default function RecipeList() {
  const [rows, setRows] = useState<AuditRow[]>([])
  const [error, setError] = useState<string | null>(null)
  const [q, setQ] = useState('')
  const [slot, setSlot] = useState<MealSlot | 'all'>('all')
  const [sortDesc, setSortDesc] = useState(false)

  // évite le double fetch (StrictMode)
  const did = useRef(false)

  useEffect(() => {
    if (did.current) return
    did.current = true

      ; (async () => {
        try {
          const r = await fetch('/api/recipes/audit')
          const raw = await r.text()
          if (!r.ok) throw new Error(`API ${r.status}: ${raw}`)
          const json: unknown = JSON.parse(raw)

          // Cas 1 : json est déjà un tableau
          let data: unknown = json

          // Cas 2 : c’est un objet { items: [...] }
          if (
            data &&
            typeof data === 'object' &&
            !Array.isArray(data) &&
            'items' in data
          ) {
            data = (data as { items: AuditRow[] }).items
          }

          if (!Array.isArray(data)) {
            console.warn('Unexpected /recipes/audit payload:', json)
            setRows([])
            return
          }

          // On force le typage
          const safe: AuditRow[] = (data as Partial<AuditRow>[])
            .filter((x): x is Partial<AuditRow> => !!x && typeof x === 'object')
            .map((x) => ({
              id: String(x.id ?? ''),
              name: String(x.name ?? '—'),
              kcal_per_portion: Number(x.kcal_per_portion ?? 0),
              protein_g: Number(x.protein_g ?? 0),
              carbs_g: Number(x.carbs_g ?? 0),
              fat_g: Number(x.fat_g ?? 0),
              meal_types: Array.isArray(x.meal_types) ? (x.meal_types as MealSlot[]) : [],
              portions: Number(x.portions ?? 1),
              dish_family: x.dish_family ?? null,
              time_min: x.time_min ?? null,
            }))

          setRows(safe)
        } catch (e: unknown) {
          setError(e instanceof Error ? e.message : String(e))
        }
      })()
  }, [])

  const filtered = useMemo(() => {
    // garde-fou si jamais rows devient non-tableau
    if (!Array.isArray(rows)) return [] as AuditRow[]

    const byText = (r: AuditRow) =>
      r.name.toLowerCase().includes(q.toLowerCase()) ||
      (r.dish_family ?? '').toLowerCase().includes(q.toLowerCase())

    const bySlot = (r: AuditRow) =>
      slot === 'all' ? true : (r.meal_types || []).includes(slot)

    const out = rows.filter((r) => byText(r) && bySlot(r))
    out.sort((a, b) =>
      sortDesc
        ? b.kcal_per_portion - a.kcal_per_portion
        : a.kcal_per_portion - b.kcal_per_portion
    )
    return out
  }, [rows, q, slot, sortDesc])

  if (error) return <div style={{ color: 'crimson' }}>Erreur: {error}</div>

  return (
    <div>
      <h2 style={{ marginTop: 0 }}>Liste des recettes</h2>

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', margin: '12px 0' }}>
        <input
          placeholder="Rechercher (nom, famille)…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          style={{ padding: 8, border: '1px solid #e5e7eb', borderRadius: 8, minWidth: 260 }}
        />
        <select
          value={slot}
          onChange={(e) => setSlot(e.target.value as MealSlot | 'all')}
          style={{ padding: 8, border: '1px solid #e5e7eb', borderRadius: 8 }}
        >
          <option value="all">Tous les slots</option>
          <option value="breakfast">Petit-déj</option>
          <option value="lunch">Déjeuner</option>
          <option value="dinner">Dîner</option>
        </select>

        <button
          onClick={() => setSortDesc((v) => !v)}
          style={{ padding: '8px 12px', border: '1px solid #e5e7eb', borderRadius: 8, background: '#f3f4f6' }}
          title="Trier par kcal"
        >
          Trier par kcal {sortDesc ? '↓' : '↑'}
        </button>
      </div>

      <div style={{ overflowX: 'auto' }}>
        <table
          style={{
            width: '100%',
            borderCollapse: 'collapse',
            background: '#fff',
            border: '1px solid #e5e7eb',
            borderRadius: 12,
            overflow: 'hidden',
          }}
        >
          <thead style={{ background: '#f8fafc' }}>
            <tr>
              <Th>Recette</Th>
              <Th>Kcal</Th>
              <Th>Prot (g)</Th>
              <Th>Glu (g)</Th>
              <Th>Lip (g)</Th>
              <Th>Portions</Th>
              <Th>Famille</Th>
              <Th>Temps</Th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id}>
                <Td style={{ fontWeight: 600 }}>{r.name}</Td>
                <Td>{Math.round(r.kcal_per_portion)}</Td>
                <Td>{Math.round(r.protein_g)}</Td>
                <Td>{Math.round(r.carbs_g)}</Td>
                <Td>{Math.round(r.fat_g)}</Td>
                <Td>{r.portions}</Td>
                <Td>{r.dish_family ?? '—'}</Td>
                <Td>{r.time_min ?? '—'} min</Td>
                <Td>
                  <Link
                    to={`/recipes/${r.id}`}
                    style={{
                      padding: '6px 10px',
                      border: '1px solid #e5e7eb',
                      borderRadius: 8,
                      background: '#f3f4f6',
                      textDecoration: 'none',
                      fontSize: 13,
                      whiteSpace: 'nowrap',
                    }}
                  >
                    Voir détail
                  </Link>
                </Td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <Td colSpan={9} style={{ textAlign: 'center', padding: 20, color: '#6b7280' }}>
                  Aucune recette trouvée.
                </Td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function Th({ children }: { children: React.ReactNode }) {
  return (
    <th
      style={{
        textAlign: 'left',
        padding: '10px 12px',
        borderBottom: '1px solid #e5e7eb',
        fontWeight: 600,
        fontSize: 13,
        color: '#111827',
        whiteSpace: 'nowrap',
      }}
    >
      {children}
    </th>
  )
}
function Td({
  children,
  style,
  colSpan,
}: {
  children: React.ReactNode
  style?: React.CSSProperties
  colSpan?: number
}) {
  return (
    <td
      colSpan={colSpan}
      style={{
        padding: '10px 12px',
        borderBottom: '1px solid #f1f5f9',
        fontSize: 14,
        ...style,
      }}
    >
      {children}
    </td>
  )
}
