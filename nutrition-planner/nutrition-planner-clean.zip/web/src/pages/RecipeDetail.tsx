// src/pages/RecipeDetail.tsx
import { useEffect, useMemo, useRef, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import type { Ingredient, MealSlot, Recipe } from '../types'
import { getRecipeById, listIngredients } from '../api'

type AuditRow = {
  id: string
  name: string
  kcal_per_portion: number
  protein_g: number
  carbs_g: number
  fat_g: number
  meal_types: MealSlot[]
  portions: number
  dish_family?: string | null
  time_min?: number | null
  cuisine?: string | null
}

// équivalents /api/recipes/:id/equivalents
type Equivalent = { recipe_id: string; scale: number; distance: number }

export default function RecipeDetail() {
  const { id } = useParams<{ id: string }>()
  const [r, setR] = useState<Recipe | null>(null)
  const [audit, setAudit] = useState<AuditRow | null>(null)
  const [ings, setIngs] = useState<Ingredient[]>([])
  const [equiv, setEquiv] = useState<Equivalent[]>([])
  const [error, setError] = useState<string | null>(null)

  // éviter double fetch en dev (StrictMode)
  const did = useRef(false)
  useEffect(() => {
    if (did.current) return
    did.current = true
    ;(async () => {
      try {
        if (!id) return
        // 1) recette
        const rec = await getRecipeById(id)
        if ('error' in rec) throw new Error('Recette introuvable')
        setR(rec)

        // 2) ingredients index
        listIngredients().then(setIngs).catch(() => {})

        // 3) audit global -> on prend la ligne de cette recette
        const ar = await fetch('/api/recipes/audit')
        const raw = await ar.text()
        if (ar.ok) {
          const json: unknown = JSON.parse(raw)
          const arr: AuditRow[] = Array.isArray(json) ? (json as AuditRow[]) : []
          const row = arr.find((x) => x.id === id) ?? null
          setAudit(row)
        }

        // 4) équivalents
        const er = await fetch(`/api/recipes/${id}/equivalents?k=6&allow_scaling=true`)
        if (er.ok) {
          const ej = await er.json()
          const list: Equivalent[] = Array.isArray(ej?.equivalents) ? ej.equivalents : []
          setEquiv(list)
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : String(e))
      }
    })()
  }, [id])

  // index {ingId -> name}
  const ingName = useMemo(() => {
    const idx = new Map<string, string>()
    ings.forEach((i) => idx.set(i.id, i.name))
    return (iid: string) => idx.get(iid) ?? iid
  }, [ings])

  if (error) return <div style={{ color: 'crimson', padding: 16 }}>Erreur: {error}</div>
  if (!r) return <div style={{ padding: 16 }}>Chargement…</div>

  const mealSlots = (r.meal_types || []) as MealSlot[]

  return (
    <div style={{ padding: 16, maxWidth: 980, margin: '0 auto' }}>
      {/* Header */}
      <h2 style={{ margin: '8px 0 12px' }}>{r.name}</h2>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, rowGap: 10, marginBottom: 18 }}>
        <Badge>Portions&nbsp;: <b>{r.portions}</b></Badge>
        <Badge>Temps&nbsp;: <b>{r.time_min ?? '—'} min</b></Badge>
        <Badge>
          Slots&nbsp;:
          &nbsp;<b>{mealSlots.length ? mealSlots.join(', ') : '—'}</b>
        </Badge>
        <Badge> Cuisine&nbsp;: <b>{r.cuisine ?? '—'}</b></Badge>
        <Badge> Famille&nbsp;: <b>{r.dish_family ?? '—'}</b></Badge>
      </div>

      {/* Macros par portion */}
      <section style={{ marginBottom: 18 }}>
        <h3 style={{ margin: '0 0 8px' }}>Macros par portion</h3>
        {audit ? (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, minmax(120px, 1fr))',
            gap: 8,
            maxWidth: 640
          }}>
            <Stat label="kcal" value={Math.round(audit.kcal_per_portion)} />
            <Stat label="Prot (g)" value={Math.round(audit.protein_g)} />
            <Stat label="Glu (g)" value={Math.round(audit.carbs_g)} />
            <Stat label="Lip (g)" value={Math.round(audit.fat_g)} />
          </div>
        ) : (
          <div style={{ fontSize: 13, color: '#6b7280' }}>— Données non disponibles —</div>
        )}
      </section>

      {/* Ingrédients */}
      <section style={{ marginTop: 8 }}>
        <h3 style={{ margin: '0 0 8px' }}>Ingrédients</h3>
        <div style={{ overflowX: 'auto' }}>
          <table
            style={{
              width: '100%',
              borderCollapse: 'collapse',
              background: '#fff',
              border: '1px solid #e5e7eb',
              borderRadius: 12,
              overflow: 'hidden',
            }}
          >
            <thead style={{ background: '#f8fafc' }}>
              <tr>
                <Th>Ingrédient</Th>
                <Th>Quantité</Th>
                <Th>État</Th>
              </tr>
            </thead>
            <tbody>
              {r.ingredients.map((ri) => (
                <tr key={`${ri.ingredient_id}-${ri.quantity_g}-${ri.state ?? ''}`}>
                  <Td style={{ fontWeight: 600 }}>{ingName(ri.ingredient_id)}</Td>
                  <Td>{ri.quantity_g} g</Td>
                  <Td>{ri.state ?? '—'}</Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Equivalents */}
      {equiv.length > 0 && (
        <section style={{ marginTop: 22 }}>
          <h3 style={{ margin: '0 0 8px' }}>Recettes équivalentes</h3>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {equiv.map((e) => (
              <Link
                key={e.recipe_id}
                to={`/recipes/${e.recipe_id}`}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '8px 12px',
                  border: '1px solid #e5e7eb',
                  borderRadius: 10,
                  textDecoration: 'none',
                  background: '#f8fafc',
                  fontSize: 14,
                }}
                title={`Échelle suggérée ×${e.scale}`}
              >
                <span style={{ fontWeight: 600 }}>{e.recipe_id}</span>
                <span style={{ fontSize: 12, opacity: 0.65 }}>×{e.scale}</span>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}

/* ---------- UI helpers ---------- */

function Badge({ children }: { children: React.ReactNode }) {
  return (
    <span
      style={{
        display: 'inline-block',
        padding: '6px 10px',
        border: '1px solid #e5e7eb',
        borderRadius: 999,
        background: '#f8fafc',
        fontSize: 13,
      }}
    >
      {children}
    </span>
  )
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div
      style={{
        border: '1px solid #e5e7eb',
        borderRadius: 12,
        padding: '10px 12px',
        background: '#ffffff',
      }}
    >
      <div style={{ fontSize: 12, color: '#6b7280' }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 700 }}>{value}</div>
    </div>
  )
}

function Th({ children }: { children: React.ReactNode }) {
  return (
    <th
      style={{
        textAlign: 'left',
        padding: '10px 12px',
        borderBottom: '1px solid #e5e7eb',
        fontWeight: 600,
        fontSize: 13,
        color: '#111827',
        whiteSpace: 'nowrap',
      }}
    >
      {children}
    </th>
  )
}

function Td({
  children,
  style,
}: {
  children: React.ReactNode
  style?: React.CSSProperties
}) {
  return (
    <td
      style={{
        padding: '10px 12px',
        borderBottom: '1px solid #f1f5f9',
        fontSize: 14,
        ...style,
      }}
    >
      {children}
    </td>
  )
}
