import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getProfile } from '../api';
import type { Profile } from '../types';

export default function ProfileDetail() {
  const params = useParams();
  const pid = params.profile_id ?? params.id ?? ''; // tolère :id ou :profile_id

  const [profile, setProfile] = useState<Profile | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(null);

    if (!pid) {
      setError('Paramètre de profil manquant dans l’URL.');
      setLoading(false);
      return;
    }

    getProfile(pid)
      .then((p) => { if (alive) setProfile(p); })
      .catch((e) => { if (alive) setError(String(e)); })
      .finally(() => { if (alive) setLoading(false); });

    return () => { alive = false; };
  }, [pid]);

  if (loading) return <div style={{ padding: 16 }}>Chargement…</div>;
  if (error) return (
    <div style={{ padding: 16, color: '#b91c1c' }}>
      Erreur: {error}{' '}
      <span style={{ color: '#6b7280' }}>(vérifie la route /profiles/:profile_id)</span>
    </div>
  );
  if (!profile) return <div style={{ padding: 16 }}>Profil introuvable.</div>;

  const p = profile;

  return (
    <div style={{ padding: 16 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 12 }}>
        <h3 style={{ margin: 0 }}>{p.first_name}</h3>
        <Link
          to="/profiles"
          style={{ fontSize: 12, textDecoration: 'none', border: '1px solid #e5e7eb', borderRadius: 6, padding: '4px 8px' }}
        >
          ← Tous les profils
        </Link>
      </div>
      <div style={{ marginBottom: 8, color: '#6b7280', fontSize: 12 }}>{p.profile_id}</div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 10 }}>
        <Card title="Infos générales">
          <Row k="Naissance" v={`${p.birth_date ?? '—'} (${ageFrom(p.birth_date)} ans)`} />
          <Row k="Genre" v={p.gender ?? '—'} />
          <Row k="Taille" v={p.height_cm != null ? `${p.height_cm} cm` : '—'} />
          <Row k="Poids" v={p.weight_kg != null ? `${p.weight_kg} kg` : '—'} />
          <Row k="Objectif" v={p.goal ?? '—'} />
          <Row k="Sport" v={p.sport_frequency ? `${p.sport_frequency}×/sem` : '—'} />
          <Row k="Activité pro" v={p.job_activity ?? '—'} />
          <Row k="Budget" v={p.food_budget_level ?? '—'} />
          <Row k="Temps/repas" v={p.max_time_per_meal_min != null ? `${p.max_time_per_meal_min} min` : '—'} />
        </Card>

        <Card title="Conditions">
          {p.conditions?.length ? (
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {p.conditions.map((c) => (
                <span key={c} style={{ border: '1px solid #e5e7eb', borderRadius: 999, padding: '2px 8px', fontSize: 12 }}>
                  {c}
                </span>
              ))}
            </div>
          ) : <Empty />}
        </Card>

        <Card title="Allergies">
          {p.allergies?.length ? (
            <ul style={{ margin: 0, paddingLeft: 18 }}>
              {p.allergies.map((a) => (
                <li key={a.ingredient_id}>
                  {a.label} <span style={{ color: '#6b7280' }}>({a.ingredient_id})</span>
                </li>
              ))}
            </ul>
          ) : <Empty />}
        </Card>

        <Card title="Aliments non aimés">
          {p.dislikes?.length ? (
            <ul style={{ margin: 0, paddingLeft: 18 }}>
              {p.dislikes.map((d) => (
                <li key={d.ingredient_id}>
                  {d.label} <span style={{ color: '#6b7280' }}>({d.ingredient_id})</span>
                </li>
              ))}
            </ul>
          ) : <Empty />}
        </Card>
      </div>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ border: '1px solid #e5e7eb', borderRadius: 8, padding: 12, background: '#fff' }}>
      <div style={{ fontWeight: 600, marginBottom: 8 }}>{title}</div>
      {children}
    </div>
  );
}
function Row({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', rowGap: 6 }}>
      <div style={{ color: '#6b7280' }}>{k}</div>
      <div>{v}</div>
    </div>
  );
}
function Empty() {
  return <div style={{ color: '#6b7280', fontSize: 14 }}>—</div>;
}
function ageFrom(iso?: string): number | string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  const now = new Date();
  let a = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) a--;
  return a;
}
