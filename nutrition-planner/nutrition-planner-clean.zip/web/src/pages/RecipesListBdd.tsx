import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import * as api from '../api'
import type { Recipe } from '../types'
import type { CourseType } from '../types'

const COURSE_LABEL: Record<CourseType | 'other', string> = {
  starter: 'Entrée',
  main: 'Plat',
  dessert: 'Dessert',
  side: 'Accompagnement',
  other: 'Autre',
}

const labelForCourse = (v?: string | null): string =>
  v ? (COURSE_LABEL[v as CourseType] ?? v) : '—'

export default function RecipesListBdd() {
  const [rows, setRows] = useState<Recipe[]>([])
  const [q, setQ] = useState('')
  const navigate = useNavigate()

  useEffect(() => { api.listRecipes().then(setRows).catch(() => setRows([])) }, [])

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase()
    return rows.filter(r => {
      if (term) {
        const hay = `${r.name ?? ''} ${(r.dish_family ?? '')} ${(r.cuisine ?? '')}`.toLowerCase()
        if (!hay.includes(term)) return false
      }
      return true
    })
  }, [rows, q])

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-4">
      <div className="flex items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Recettes (BDD)</h1>
          <p className="text-sm text-gray-500">Depuis /api/recipes</p>
        </div>
        <input
          className="border rounded-lg px-3 py-2 w-64"
          placeholder="Rechercher…"
          value={q}
          onChange={e => setQ(e.target.value)}
        />
      </div>

      <div className="border rounded-2xl overflow-hidden bg-white shadow-sm">
        <div className="hidden md:grid grid-cols-[minmax(14rem,1fr)_8rem_12rem_6rem_6rem] bg-gray-50 text-sm font-medium">
          <div className="px-3 py-2">Nom</div>
          <div className="px-3 py-2">Type</div>
          <div className="px-3 py-2">Repas</div>
          <div className="px-3 py-2 text-right">Portions</div>
          <div className="px-3 py-2 text-right">Temps</div>
        </div>

        <div className="divide-y">
          {filtered.map(r => (
            <div
              key={r.id}
              role="button"
              tabIndex={0}
              onClick={() => navigate(`/recipes/bdd/${r.id}`)}
              onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && navigate(`/recipes/bdd/${r.id}`)}
              className="grid grid-cols-1 md:grid-cols-[minmax(14rem,1fr)_8rem_12rem_6rem_6rem] items-center hover:bg-gray-50 cursor-pointer transition"
            >
              <div className="px-3 py-2 flex items-center gap-3">
                {r.image ? (
                  <img src={r.image} alt="" className="w-10 h-10 rounded object-cover border" />
                ) : (
                  <div className="w-10 h-10 rounded bg-gray-100 border" />
                )}
                <div>
                  <div className="font-medium">{r.name}</div>
                  <div className="text-xs text-gray-500">{[r.dish_family, r.cuisine].filter(Boolean).join(' • ') || '—'}</div>
                </div>
              </div>

              <div className="px-3 py-2">{labelForCourse(r.course_type)}</div>

              <div className="px-3 py-2 text-gray-700">
                {r.meal_types?.length ? r.meal_types.join(', ') : '—'}
              </div>

              <div className="px-3 py-2 text-right">{r.servings ?? '—'}</div>
              <div className="px-3 py-2 text-right">{r.time_min ?? '—'}</div>
            </div>
          ))}

          {filtered.length === 0 && (
            <div className="px-3 py-8 text-center text-gray-500">Aucune recette</div>
          )}
        </div>
      </div>
    </div>
  )
}
