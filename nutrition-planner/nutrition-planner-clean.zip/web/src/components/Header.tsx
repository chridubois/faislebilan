import { Link, NavLink } from 'react-router-dom';

function Logo() {
  return (
    <Link to="/planner" style={{ display: 'flex', alignItems: 'center', gap: 8, textDecoration: 'none' }}>
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" aria-hidden>
        <circle cx="12" cy="12" r="10" stroke="#0ea5e9" strokeWidth="2"/>
        <path d="M7 13c3 2 7 2 10 0" stroke="#0ea5e9" strokeWidth="2" strokeLinecap="round"/>
        <path d="M9 9h6" stroke="#0ea5e9" strokeWidth="2" strokeLinecap="round"/>
      </svg>
      <b style={{ color: '#0f172a' }}>Nutri Planner</b>
    </Link>
  );
}

export default function Header() {
  const linkStyle: React.CSSProperties = { textDecoration: 'none', color: '#0f172a', padding: '6px 10px', borderRadius: 6 };
  const activeStyle: React.CSSProperties = { background: '#e2e8f0' };

  return (
    <header style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '10px 16px', borderBottom: '1px solid #e5e7eb', marginBottom: 12, background: '#fff'
    }}>
      <Logo />
      <nav style={{ display: 'flex', gap: 8 }}>
        <NavLink to="/planner" style={({isActive}) => ({...linkStyle, ...(isActive?activeStyle:{})})}>Planner</NavLink>
        <NavLink to="/ingredients" style={({isActive}) => ({...linkStyle, ...(isActive?activeStyle:{})})}>Ingrédients</NavLink>
        <NavLink to="/recipes" style={({isActive}) => ({...linkStyle, ...(isActive?activeStyle:{})})}>Recettes</NavLink>
        <NavLink to="/profiles" style={({isActive}) => ({...linkStyle, ...(isActive?activeStyle:{})})}>Profils</NavLink>
      </nav>
    </header>
  );
}
