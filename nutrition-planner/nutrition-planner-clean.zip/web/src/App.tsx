import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom'
import Planner from './pages/Planner'
import IngredientList from './pages/IngredientList'
// import RecipeList from './pages/RecipeList'
import TargetsPage from './pages/TargetsPage'
import IngredientDetail from './pages/IngredientDetail'
// import RecipeDetail from './pages/RecipeDetail'
import ProfileDetail from './pages/ProfileDetail'
import Profiles from './pages/Profiles'
import CiqualIngredients from './pages/CiqualIngredientList'
import RecipeBuilder from './pages/recipes/Create'
import './App.css' // <-- important
// import RecipesListBdd from './pages/RecipesListBdd'
import RecipeBdd from './pages/RecipeBdd'
import RecipesBrowse from './pages/RecipesBrowse';

export default function App() {
  return (
    <Router>
      <header className="app-header">
        <Link to="/" className="app-logo">🍽️ NutriPlanner</Link>
        <nav className="app-nav">
          <Link to="/" className="app-link">Planner</Link>
          <Link to="/ingredients" className="app-link">Ingrédients</Link>
          <Link to="/ciqual">Ingrédients CIQUAL</Link>
          <Link to="/recipes/browse" className="app-link">Explorer recettes</Link>
          <Link to="/recipes/create" className="app-link">Créer une recette</Link>
          {/* <Link to="/recipes/bdd" className="app-link">Mes recettes</Link> */}
          <Link to="/targets" className="app-link">Targets</Link>
          <Link to="/profiles" className="app-link">Profils</Link>
        </nav>
      </header>

      <main className="app-main">
        <Routes>
          <Route path="/" element={<Planner />} />
          <Route path="/ingredients" element={<IngredientList />} />
          <Route path="/ciqual" element={<CiqualIngredients />} />
          <Route path="/ingredients/:id" element={<IngredientDetail />} />
          {/* <Route path="/recipes" element={<RecipeList />} /> */}
          {/* <Route path="/recipes/:id" element={<RecipeDetail />} /> */}
          <Route path="/targets" element={<TargetsPage />} />
          <Route path="/profiles" element={<Profiles />} />
          <Route path="/profiles/:id" element={<ProfileDetail />} />
          <Route path="/recipes/create" element={<RecipeBuilder />} />
          {/* <Route path="/recipes/bdd" element={<RecipesListBdd />} />
          <Route path="/recipes/bdd" element={<RecipesListBdd />} /> */}
          <Route path="/recipes/bdd/:id" element={<RecipeBdd />} />
          <Route path="/recipes/browse" element={<RecipesBrowse />} />
        </Routes>
      </main>
    </Router>
  )
}
