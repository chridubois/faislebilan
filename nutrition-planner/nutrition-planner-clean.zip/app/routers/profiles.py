
from __future__ import annotations
from fastapi import APIRouter, HTTPException
from app.utils.loader import load_profiles, load_targets
from app.services.targets import compute_targets_for_profile

router = APIRouter()

@router.get("/targets")
def targets():
    return load_targets()

@router.get("/profiles", summary="Liste tous les profils")
def list_profiles():
    """
    Retourne la liste complète des profils.
    """
    return load_profiles() or []

@router.get("/profiles/{profile_id}", summary="Récupère un profil par id")
def get_profile(profile_id: str):
    """
    Retourne un profil par son identifiant, sinon 404.
    """
    for p in load_profiles() or []:
        if p.get("profile_id") == profile_id:
            return p
    raise HTTPException(status_code=404, detail="Profile not found")

@router.get("/profiles/{profile_id}/targets", summary="Cibles calculées pour un profil")
def get_profile_targets(profile_id: str):
    for p in load_profiles() or []:
        if p.get("profile_id") == profile_id:
            return compute_targets_for_profile(p)
    raise HTTPException(status_code=404, detail="Profile not found")
