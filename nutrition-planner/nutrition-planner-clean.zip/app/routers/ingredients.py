# app/routers/ingredients.py
from __future__ import annotations
from fastapi import APIRouter, Depends, Query, HTTPException
from app.utils.loader import load_ingredients
from typing import List, Optional
from app.schemas.ingredients import Ingredient, IngredientCiqual
from app.services.supabase import select, post_rpc
from app.deps.auth import get_user_token

router = APIRouter(prefix="/ingredients", tags=["ingredients"])

@router.get("", response_model=List[Ingredient])
def list_ingredients():
    # version actuelle: JSON local
    return load_ingredients() or []

@router.get("/{ingredient_id}", response_model=Ingredient)
def get_ingredient(ingredient_id: str):
    data = load_ingredients() or []
    it = next((x for x in data if x.get("id") == ingredient_id), None)
    if not it:
        raise HTTPException(404, "not_found")
    return it
